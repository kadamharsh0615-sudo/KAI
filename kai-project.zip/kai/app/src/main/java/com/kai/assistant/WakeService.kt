package com.kai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException

class WakeService : Service(), RecognitionListener {
    companion object {
        var onEvent: ((String) -> Unit)? = null
        const val LISTENING = "Listening for “Hey Kai”"
    }

    private val wakeGrammar = "[\"hey kai\", \"hey kye\", \"hey ky\", \"[unk]\"]"
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var sr: SpeechRecognizer? = null
    private var commandMode = false
    private var lastWake = 0L
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kai", "Kai", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification("Loading Kai…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        StorageService.unpack(this, "model", "model",
            { m: Model -> model = m; listen(wakeGrammar, 0); update(LISTENING) },
            { e: IOException -> update("Could not load voice model: ${e.message}") })
    }

    private fun listen(grammar: String?, timeoutMs: Int) {
        speech?.stop()
        speech?.shutdown()
        speech = null
        try {
            val rec = if (grammar == null) Recognizer(model, 16000.0f)
                      else Recognizer(model, 16000.0f, grammar)
            val s = SpeechService(rec, 16000.0f)
            speech = s
            if (timeoutMs > 0) s.startListening(this, timeoutMs) else s.startListening(this)
        } catch (e: IOException) {
            update("Could not start the microphone: ${e.message}")
        }
    }

    private fun backToWake(msg: String) {
        commandMode = false
        listen(wakeGrammar, 0)
        update(msg)
        handler.postDelayed({ if (!commandMode) update(LISTENING) }, 5000)
    }

    private fun wakeCheck(text: String?) {
        if (commandMode || text == null || !text.lowercase().contains("hey k")) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 3000) return
        lastWake = now
        getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        commandMode = true
        update("Listening… say your command")
        handler.postDelayed({ startCommand() }, 400)
    }

    private fun startCommand() {
        speech?.stop()
        speech?.shutdown()
        speech = null
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            backToWake("Google speech service is not available on this phone")
            return
        }
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { finishCommand(null) }
            override fun onResults(results: Bundle?) {
                finishCommand(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) update("Hearing: $t")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    private fun finishCommand(text: String?) {
        sr?.destroy()
        sr = null
        if (text.isNullOrBlank()) {
            backToWake("I didn’t hear a command. Check your internet and try again")
            return
        }
        val reply = CommandRunner.run(this, text)
        backToWake("“$text” → $reply")
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, "kai")
            .setContentTitle("Kai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
        onEvent?.invoke(text)
    }

    override fun onPartialResult(hypothesis: String?) {
        if (commandMode) {
            val p = try { JSONObject(hypothesis ?: "{}").optString("partial") } catch (e: Exception) { "" }
            if (p.isNotBlank()) update("Hearing: $p")
        } else wakeCheck(hypothesis)
    }

    override fun onResult(hypothesis: String?) {
        if (commandMode) {
            val t = try { JSONObject(hypothesis ?: "{}").optString("text").trim() } catch (e: Exception) { "" }
            if (t.isNotBlank()) {
                commandMode = false
                handler.post {
                    val reply = CommandRunner.run(this, t)
                    backToWake("“$t” → $reply")
                }
            }
        } else wakeCheck(hypothesis)
    }

    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { update("Error: ${exception?.message}") }
    override fun onTimeout() {
        if (commandMode) handler.post { backToWake("I didn’t hear a command") }
    }

    override fun onDestroy() {
        sr?.destroy()
        speech?.stop()
        speech?.shutdown()
        model?.close()
        super.onDestroy()
    }
}
