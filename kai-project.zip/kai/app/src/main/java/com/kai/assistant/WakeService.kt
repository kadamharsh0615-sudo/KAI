package com.kai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException

class WakeService : Service(), RecognitionListener {
    companion object {
        var onEvent: ((String) -> Unit)? = null
        const val LISTENING = "Listening for “Hey Kai”"
    }

    private val wakeGrammar = "[\"hey kai\", \"hey kye\", \"hey ky\", \"[unk]\"]"
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var commandMode = false
    private var lastWake = 0L
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kai", "Kai", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification("Loading Kai…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        StorageService.unpack(this, "model", "model",
            { m: Model -> model = m; listen(wakeGrammar, 0); update(LISTENING) },
            { e: IOException -> update("Could not load voice model: ${e.message}") })
    }

    private fun listen(grammar: String?, timeoutMs: Int) {
        speech?.stop()
        speech?.shutdown()
        speech = null
        try {
            val rec = if (grammar == null) Recognizer(model, 16000.0f)
                      else Recognizer(model, 16000.0f, grammar)
            val s = SpeechService(rec, 16000.0f)
            speech = s
            if (timeoutMs > 0) s.startListening(this, timeoutMs) else s.startListening(this)
        } catch (e: IOException) {
            update("Could not start the microphone: ${e.message}")
        }
    }

    private fun backToWake(msg: String) {
        commandMode = false
        listen(wakeGrammar, 0)
        update(msg)
        handler.postDelayed({ if (!commandMode) update(LISTENING) }, 5000)
    }

    private fun wakeCheck(text: String?) {
        if (commandMode || text == null || !text.lowercase().contains("hey k")) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 3000) return
        lastWake = now
        getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        handler.post {
            commandMode = true
            listen(null, 8000)
            update("Listening… say your command")
        }
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, "kai")
            .setContentTitle("Kai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
        onEvent?.invoke(text)
    }

    override fun onPartialResult(hypothesis: String?) {
        if (commandMode) {
            val p = try { JSONObject(hypothesis ?: "{}").optString("partial") } catch (e: Exception) { "" }
            if (p.isNotBlank()) update("Hearing: $p")
        } else wakeCheck(hypothesis)
    }

    override fun onResult(hypothesis: String?) {
        if (commandMode) {
            val t = try { JSONObject(hypothesis ?: "{}").optString("text").trim() } catch (e: Exception) { "" }
            if (t.isNotBlank()) {
                commandMode = false
                handler.post {
                    val reply = CommandRunner.run(this, t)
                    backToWake("“$t” → $reply")
                }
            }
        } else wakeCheck(hypothesis)
    }

    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { update("Error: ${exception?.message}") }
    override fun onTimeout() {
        if (commandMode) handler.post { backToWake("I didn’t hear a command") }
    }

    override fun onDestroy() {
        speech?.stop()
        speech?.shutdown()
        model?.close()
        super.onDestroy()
    }
}
