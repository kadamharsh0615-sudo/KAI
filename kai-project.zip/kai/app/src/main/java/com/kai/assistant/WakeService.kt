package com.kai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException

class WakeService : Service(), RecognitionListener {
    companion object {
        var onEvent: ((String) -> Unit)? = null
    }

    private var model: Model? = null
    private var speech: SpeechService? = null
    private var lastWake = 0L
    private val handler = Handler()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kai", "Kai", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification("Loading Kai…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        StorageService.unpack(this, "model", "model",
            { m: Model -> model = m; startListening() },
            { e: IOException -> update("Could not load voice model: ${e.message}") })
    }

    private fun startListening() {
        try {
            val grammar = "[\"hey kai\", \"hey kye\", \"hey ky\", \"[unk]\"]"
            val rec = Recognizer(model, 16000.0f, grammar)
            speech = SpeechService(rec, 16000.0f)
            speech?.startListening(this)
            update("Listening for “Hey Kai”")
        } catch (e: IOException) {
            update("Could not start the microphone: ${e.message}")
        }
    }

    private fun heard(text: String?) {
        if (text == null || !text.lowercase().contains("hey k")) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 3000) return
        lastWake = now
        update("Heard “Hey Kai”")
        getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        handler.postDelayed({ update("Listening for “Hey Kai”") }, 3000)
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, "kai")
            .setContentTitle("Kai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
        onEvent?.invoke(text)
    }

    override fun onPartialResult(hypothesis: String?) = heard(hypothesis)
    override fun onResult(hypothesis: String?) = heard(hypothesis)
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { update("Error: ${exception?.message}") }
    override fun onTimeout() {}

    override fun onDestroy() {
        speech?.stop()
        speech?.shutdown()
        model?.close()
        super.onDestroy()
    }
}
