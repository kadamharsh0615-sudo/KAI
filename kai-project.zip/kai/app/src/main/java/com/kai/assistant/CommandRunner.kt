package com.kai.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract

object CommandRunner {
    private val nums = mapOf(
        "zero" to 0, "oh" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
        "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16,
        "seventeen" to 17, "eighteen" to 18, "nineteen" to 19, "twenty" to 20, "thirty" to 30,
        "forty" to 40, "fifty" to 50
    )
    private val aliases = mapOf(
        "what's app" to "whatsapp", "whats app" to "whatsapp", "what app" to "whatsapp",
        "what's up" to "whatsapp", "insta gram" to "instagram", "snap chat" to "snapchat",
        "you tube" to "youtube", "g mail" to "gmail"
    )

    fun run(ctx: Context, raw: String): String {
        val t = raw.lowercase()
            .replace("a.m.", "am").replace("p.m.", "pm").replace("a.m", "am").replace("p.m", "pm")
            .replace(Regex("(\\d)(am|pm)"), "$1 $2")
            .trim()
            .replace(Regex("^(hey|hi|high|ok|okay)?[ ,]*(kai|kye|ky|kay|kaye|ki)\\b[ ,.]*"), "")
            .trim()
        return try {
            when {
                t.startsWith("open ") || t.startsWith("launch ") || t.startsWith("start ") ->
                    openApp(ctx, t.substringAfter(" ").trim())
                t.startsWith("search ") || t.startsWith("google ") ->
                    search(ctx, t.substringAfter(" ").removePrefix("for ").trim())
                t.startsWith("call ") -> call(ctx, t.removePrefix("call ").trim())
                t.contains("alarm") -> alarm(ctx, t)
                t.contains("timer") -> timer(ctx, t)
                else -> "I don’t know that command yet"
            }
        } catch (e: Exception) {
            "Something went wrong: ${e.message}"
        }
    }

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun openApp(ctx: Context, spoken: String): String {
        var name = spoken.removePrefix("the ").removeSuffix(" app").trim()
        for ((k, v) in aliases) name = name.replace(k, v)
        if (name.isEmpty()) return "Which app should I open?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
        val hit = list.firstOrNull { it.first == name }
            ?: list.firstOrNull { it.first.startsWith(name) }
            ?: list.firstOrNull { it.first.contains(name) }
            ?: list.minByOrNull { lev(it.first, name) }?.takeIf { lev(it.first, name) <= maxOf(2, name.length / 3) }
            ?: return "I couldn’t find an app named $name"
        val intent = pm.getLaunchIntentForPackage(hit.second) ?: return "I couldn’t open $name"
        launch(ctx, intent)
        return "Opening ${hit.first}"
    }

    private fun search(ctx: Context, q: String): String {
        if (q.isEmpty()) return "What should I search for?"
        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Searching for $q"
    }

    private fun call(ctx: Context, name: String): String {
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        ) ?: return "I can’t read your contacts"
        val all = mutableListOf<Pair<String, String>>()
        cur.use {
            while (it.moveToNext()) {
                val n = it.getString(0)?.lowercase() ?: continue
                val num = it.getString(1) ?: continue
                all.add(n to num)
            }
        }
        val hit = all.firstOrNull { it.first == name }
            ?: all.firstOrNull { it.first.contains(name) || name.contains(it.first) }
            ?: all.minByOrNull { lev(it.first.substringBefore(" "), name) }
                ?.takeIf { lev(it.first.substringBefore(" "), name) <= 2 }
            ?: return "No contact named $name"
        launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(hit.second))))
        return "Calling ${hit.first}"
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun num(tokens: List<String>, i: Int): Pair<Int, Int>? {
        if (i >= tokens.size) return null
        val a = nums[tokens[i]] ?: tokens[i].toIntOrNull() ?: return null
        if (a in listOf(20, 30, 40, 50) && i + 1 < tokens.size) {
            val b = nums[tokens[i + 1]]
            if (b != null && b in 1..9) return Pair(a + b, 2)
        }
        return Pair(a, 1)
    }

    private fun alarm(ctx: Context, t: String): String {
        val tokens = t.split(" ").filter { it.isNotBlank() }
        var h = -1
        var m = 0
        val colon = tokens.firstOrNull { Regex("^\\d{1,2}:\\d{2}$").matches(it) }
        if (colon != null) {
            h = colon.substringBefore(":").toInt(); m = colon.substringAfter(":").toInt()
        } else {
            val start = tokens.indices.firstOrNull { num(tokens, it) != null } ?: -1
            if (start < 0) return "What time should I set the alarm for?"
            val first = num(tokens, start)!!
            h = first.first
            var j = start + first.second
            val n2 = num(tokens, j)
            if (n2 != null) {
                m = n2.first; j += n2.second
                if (m == 0) { val n3 = num(tokens, j); if (n3 != null) m = n3.first }
            }
        }
        val tail = t.substringAfter(" ")
        val pm = tail.contains("pm") || tail.contains("p m")
        val am = tail.contains("am") || tail.contains("a m")
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (h !in 0..23 || m !in 0..59) return "I didn’t understand that time"
        launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Kai")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarm set for %02d:%02d".format(h, m)
    }

    private fun timer(ctx: Context, t: String): String {
        val tokens = t.split(" ").filter { it.isNotBlank() }
        var value = -1
        for (i in tokens.indices) {
            val n = num(tokens, i)
            if (n != null) { value = n.first; break }
        }
        if (value <= 0) return "How long should the timer be?"
        val secs = when {
            t.contains("hour") -> value * 3600
            t.contains("second") -> value
            else -> value * 60
        }
        launch(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer set for $value ${if (t.contains("hour")) "hours" else if (t.contains("second")) "seconds" else "minutes"}"
    }
}
