package com.kai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply { text = "Kai"; textSize = 38f; gravity = Gravity.CENTER }
        status = TextView(this).apply {
            text = "Kai is off"; textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 48)
        }
        val start = Button(this).apply { text = "Start listening"; setOnClickListener { startKai() } }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WakeService::class.java))
                status.text = "Kai is off"
            }
        }
        box.addView(title); box.addView(status); box.addView(start); box.addView(stop)
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        WakeService.onEvent = { msg -> runOnUiThread { status.text = msg } }
    }

    override fun onPause() {
        super.onPause()
        WakeService.onEvent = null
    }

    private fun startKai() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) launchService() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchService()
        } else {
            status.text = "Kai needs microphone permission"
        }
    }

    private fun launchService() {
        status.text = "Starting…"
        startForegroundService(Intent(this, WakeService::class.java))
    }
}
