package com.kai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val title = TextView(this).apply { text = "Kai"; textSize = 38f; gravity = Gravity.CENTER }
        status = TextView(this).apply {
            text = "Kai is off"; textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 48)
        }
        val overlay = Button(this).apply {
            text = "1. Allow Kai to open apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName"))
                    )
                } else {
                    status.text = "Already allowed"
                }
            }
        }
        val start = Button(this).apply { text = "2. Start listening"; setOnClickListener { startKai() } }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WakeService::class.java))
                status.text = "Kai is off"
            }
        }
        val help = TextView(this).apply {
            text = "Try: “Hey Kai” … “open WhatsApp”, “search best laptops”, “set alarm for six thirty a m”, “call Maa”, “set timer for ten minutes”"
            textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 48, 0, 0)
        }
        box.addView(title); box.addView(status); box.addView(overlay)
        box.addView(start); box.addView(stop); box.addView(help)
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        WakeService.onEvent = { msg -> runOnUiThread { status.text = msg } }
    }

    override fun onPause() {
        super.onPause()
        WakeService.onEvent = null
    }

    private fun startKai() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) launchService() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchService()
        } else {
            status.text = "Kai needs microphone permission"
        }
    }

    private fun launchService() {
        status.text = "Starting…"
        startForegroundService(Intent(this, WakeService::class.java))
    }
}
